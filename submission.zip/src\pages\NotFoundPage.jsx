import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function NotFoundPage() {
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  return (
    <section className="not-found-page">
      <h2>{t.pageNotFound}</h2>
      <p>{t.pageNotFoundDesc}</p>
      <Link to="/" className="back-link">
        {t.backToHome}
      </Link>
    </section>
  );
}

export default NotFoundPage;
