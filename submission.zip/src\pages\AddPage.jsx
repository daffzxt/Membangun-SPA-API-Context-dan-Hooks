import React, { useContext, useState } from 'react';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import { FiCheck } from 'react-icons/fi';
import { addNote } from '../utils/network-data';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function AddPage({ setLoading }) {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  const TITLE_LIMIT = 50;

  function onTitleChangeHandler(event) {
    if (event.target.value.length <= TITLE_LIMIT) {
      setTitle(event.target.value);
    }
  }

  function onBodyInputHandler(event) {
    setBody(event.target.innerHTML);
  }

  async function onSubmitHandler(event) {
    event.preventDefault();
    if (!title.trim() || !body.trim()) return;

    if (setLoading) setLoading(true);
    const { error } = await addNote({ title, body });
    if (setLoading) setLoading(false);

    if (!error) {
      navigate('/');
    }
  }

  return (
    <section className="add-new-page">
      <h2>{t.addNote}</h2>
      <form className="add-new-page__input" onSubmit={onSubmitHandler}>
        <p className="add-new-page__title__char-limit">
          {t.charsLeft}
          {TITLE_LIMIT - title.length}
        </p>
        <input
          className="add-new-page__input__title"
          type="text"
          placeholder={t.titlePlaceholder}
          value={title}
          onChange={onTitleChangeHandler}
          required
        />
        <div
          className="add-new-page__input__body"
          contentEditable
          data-placeholder={t.bodyPlaceholder}
          onInput={onBodyInputHandler}
        />
        <div className="add-new-page__action">
          <button className="action" type="submit" title={t.saveNote} aria-label={t.saveNote}>
            <FiCheck />
          </button>
        </div>
      </form>
    </section>
  );
}

AddPage.propTypes = {
  setLoading: PropTypes.func,
};

export default AddPage;
