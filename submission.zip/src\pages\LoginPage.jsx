import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import LoginInput from '../components/LoginInput';
import { login } from '../utils/network-data';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function LoginPage({ loginSuccess, setLoading }) {
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  async function onLogin({ email, password }) {
    if (setLoading) setLoading(true);
    const { error, data } = await login({ email, password });
    if (setLoading) setLoading(false);

    if (!error) {
      loginSuccess(data);
    }
  }

  return (
    <section className="login-page">
      <h2>{t.loginTitle}</h2>
      <LoginInput login={onLogin} />
      <p className="auth-footer">
        {t.dontHaveAccount} <Link to="/register">{t.registerHere}</Link>
      </p>
    </section>
  );
}

LoginPage.propTypes = {
  loginSuccess: PropTypes.func.isRequired,
  setLoading: PropTypes.func,
};

export default LoginPage;
