import React, { useState, useEffect, useContext } from 'react';
import PropTypes from 'prop-types';
import { useParams, useNavigate } from 'react-router-dom';
import { FiArchive, FiInbox, FiTrash2 } from 'react-icons/fi';
import { getNote, archiveNote, unarchiveNote, deleteNote } from '../utils/network-data';
import { showFormattedDate, translations } from '../utils/content';
import LocaleContext from '../contexts/LocaleContext';

function DetailPage({ setLoading }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [note, setNote] = useState(null);
  const [isNotFound, setIsNotFound] = useState(false);
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  useEffect(() => {
    async function fetchNoteDetail() {
      if (setLoading) setLoading(true);
      const { error, data } = await getNote(id);
      if (error || !data) {
        setIsNotFound(true);
      } else {
        setNote(data);
      }
      if (setLoading) setLoading(false);
    }

    fetchNoteDetail();
  }, [id, setLoading]);

  async function onArchiveHandler() {
    if (setLoading) setLoading(true);
    const { error } = await archiveNote(id);
    if (setLoading) setLoading(false);
    if (!error) {
      navigate('/');
    }
  }

  async function onUnarchiveHandler() {
    if (setLoading) setLoading(true);
    const { error } = await unarchiveNote(id);
    if (setLoading) setLoading(false);
    if (!error) {
      navigate('/archives');
    }
  }

  async function onDeleteHandler() {
    if (setLoading) setLoading(true);
    const { error } = await deleteNote(id);
    if (setLoading) setLoading(false);
    if (!error) {
      navigate(note?.archived ? '/archives' : '/');
    }
  }

  if (isNotFound) {
    return (
      <section className="not-found-page">
        <h2>{t.noteNotFound}</h2>
        <p>{t.pageNotFoundDesc}</p>
      </section>
    );
  }

  if (!note) {
    return null;
  }

  return (
    <section className="detail-page">
      <h2 className="detail-page__title">{note.title}</h2>
      <p className="detail-page__createdAt">{showFormattedDate(note.createdAt, locale)}</p>
      <div className="detail-page__body">{note.body}</div>
      <div className="detail-page__action">
        {note.archived ? (
          <button
            className="action"
            type="button"
            title={t.unarchive}
            aria-label={t.unarchive}
            onClick={onUnarchiveHandler}
          >
            <FiInbox />
          </button>
        ) : (
          <button
            className="action"
            type="button"
            title={t.archive}
            aria-label={t.archive}
            onClick={onArchiveHandler}
          >
            <FiArchive />
          </button>
        )}
        <button
          className="action action-delete"
          type="button"
          title={t.delete}
          aria-label={t.delete}
          onClick={onDeleteHandler}
        >
          <FiTrash2 />
        </button>
      </div>
    </section>
  );
}

DetailPage.propTypes = {
  setLoading: PropTypes.func,
};

export default DetailPage;
