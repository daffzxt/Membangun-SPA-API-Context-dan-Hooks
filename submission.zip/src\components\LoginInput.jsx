import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import useInput from '../hooks/useInput';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function LoginInput({ login }) {
  const [email, onEmailChangeHandler] = useInput('');
  const [password, onPasswordChangeHandler] = useInput('');
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  const onSubmitHandler = (event) => {
    event.preventDefault();
    login({ email, password });
  };

  return (
    <form onSubmit={onSubmitHandler} className="input-login">
      <div>
        <label htmlFor="email">{t.emailLabel}</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={onEmailChangeHandler}
          required
          autoComplete="email"
        />
      </div>
      <div>
        <label htmlFor="password">{t.passwordLabel}</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={onPasswordChangeHandler}
          required
          autoComplete="current-password"
        />
      </div>
      <button type="submit">{t.loginButton}</button>
    </form>
  );
}

LoginInput.propTypes = {
  login: PropTypes.func.isRequired,
};

export default LoginInput;
