import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { Link, useNavigate } from 'react-router-dom';
import RegisterInput from '../components/RegisterInput';
import { register } from '../utils/network-data';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function RegisterPage({ setLoading }) {
  const navigate = useNavigate();
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  async function onRegisterHandler(user) {
    if (setLoading) setLoading(true);
    const { error } = await register(user);
    if (setLoading) setLoading(false);

    if (!error) {
      navigate('/login');
    }
  }

  return (
    <section className="register-page">
      <h2>{t.registerTitle}</h2>
      <RegisterInput register={onRegisterHandler} />
      <p className="auth-footer">
        {t.alreadyHaveAccount} <Link to="/login">{t.loginHere}</Link>
      </p>
    </section>
  );
}

RegisterPage.propTypes = {
  setLoading: PropTypes.func,
};

export default RegisterPage;
