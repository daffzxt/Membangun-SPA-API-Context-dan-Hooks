import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { Link, useLocation } from 'react-router-dom';
import { FiSun, FiMoon, FiGlobe, FiLogOut, FiUser } from 'react-icons/fi';
import ThemeContext from '../contexts/ThemeContext';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function Navigation({ authedUser, logout }) {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const { locale, toggleLocale } = useContext(LocaleContext);
  const location = useLocation();

  const t = translations[locale];

  return (
    <header>
      <h1>
        <Link to="/">{t.appTitle}</Link>
      </h1>
      <nav className="navigation-bar">
        {authedUser && (
          <ul>
            <li>
              <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
                {t.activeNotes}
              </Link>
            </li>
            <li>
              <Link to="/archives" className={location.pathname === '/archives' ? 'active' : ''}>
                {t.archivedNotes}
              </Link>
            </li>
          </ul>
        )}
        <button
          className="toggle-btn toggle-theme"
          onClick={toggleTheme}
          type="button"
          aria-label="Toggle Theme"
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {theme === 'dark' ? <FiSun /> : <FiMoon />}
        </button>
        <button
          className="toggle-btn toggle-locale"
          onClick={toggleLocale}
          type="button"
          aria-label="Toggle Language"
          title="Switch Language"
        >
          <FiGlobe style={{ marginRight: '4px' }} />
          {locale.toUpperCase()}
        </button>
        {authedUser && (
          <>
            <div className="user-profile" title={authedUser.email}>
              <FiUser />
              <span>{authedUser.name}</span>
            </div>
            <button
              className="button-logout"
              onClick={logout}
              type="button"
              title={t.logout}
            >
              <FiLogOut />
              <span>{t.logout}</span>
            </button>
          </>
        )}
      </nav>
    </header>
  );
}

Navigation.propTypes = {
  authedUser: PropTypes.object,
  logout: PropTypes.func.isRequired,
};

export default Navigation;
