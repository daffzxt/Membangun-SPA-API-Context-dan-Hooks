import React, { useState, useEffect, useContext } from 'react';
import PropTypes from 'prop-types';
import { useSearchParams, Link } from 'react-router-dom';
import { FiPlus } from 'react-icons/fi';
import SearchBar from '../components/SearchBar';
import NoteList from '../components/NoteList';
import { getActiveNotes } from '../utils/network-data';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function HomePage({ setLoading }) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [notes, setNotes] = useState([]);
  const [keyword, setKeyword] = useState(() => searchParams.get('title') || '');
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  useEffect(() => {
    async function fetchNotes() {
      if (setLoading) setLoading(true);
      const { error, data } = await getActiveNotes();
      if (!error) {
        setNotes(data);
      }
      if (setLoading) setLoading(false);
    }

    fetchNotes();
  }, [setLoading]);

  function onKeywordChangeHandler(newKeyword) {
    setKeyword(newKeyword);
    setSearchParams(newKeyword ? { title: newKeyword } : {});
  }

  const filteredNotes = notes.filter((note) =>
    note.title.toLowerCase().includes(keyword.toLowerCase())
  );

  return (
    <section className="homepage">
      <h2>{t.activeNotes}</h2>
      <SearchBar keyword={keyword} keywordChange={onKeywordChangeHandler} />
      <NoteList notes={filteredNotes} emptyMessage={t.noActiveNotes} />
      <div className="homepage__action">
        <Link to="/notes/new" className="action" title={t.addNote} aria-label={t.addNote}>
          <FiPlus />
        </Link>
      </div>
    </section>
  );
}

HomePage.propTypes = {
  setLoading: PropTypes.func,
};

export default HomePage;
