import React, { useState, useEffect, useMemo } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import Navigation from './components/Navigation';
import LoadingIndicator from './components/LoadingIndicator';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import HomePage from './pages/HomePage';
import ArchivedPage from './pages/ArchivedPage';
import AddPage from './pages/AddPage';
import DetailPage from './pages/DetailPage';
import NotFoundPage from './pages/NotFoundPage';
import { getAccessToken, putAccessToken, getUserLogged } from './utils/network-data';
import { ThemeProvider } from './contexts/ThemeContext';
import { LocaleProvider } from './contexts/LocaleContext';

function App() {
  const [authedUser, setAuthedUser] = useState(null);
  const [initializing, setInitializing] = useState(true);
  const [loading, setLoading] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark');
  const [locale, setLocale] = useState(() => localStorage.getItem('locale') || 'id');
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    async function fetchUser() {
      const accessToken = getAccessToken();
      if (accessToken) {
        const { error, data } = await getUserLogged();
        if (!error) {
          setAuthedUser(data);
        } else {
          putAccessToken('');
          setAuthedUser(null);
        }
      }
      setInitializing(false);
    }

    fetchUser();
  }, []);

  const toggleTheme = () => {
    setTheme((prevTheme) => {
      const newTheme = prevTheme === 'dark' ? 'light' : 'dark';
      localStorage.setItem('theme', newTheme);
      return newTheme;
    });
  };

  const toggleLocale = () => {
    setLocale((prevLocale) => {
      const newLocale = prevLocale === 'id' ? 'en' : 'id';
      localStorage.setItem('locale', newLocale);
      return newLocale;
    });
  };

  const themeContextValue = useMemo(() => ({
    theme,
    toggleTheme,
  }), [theme]);

  const localeContextValue = useMemo(() => ({
    locale,
    toggleLocale,
  }), [locale]);

  async function onLoginSuccess({ accessToken }) {
    putAccessToken(accessToken);
    setLoading(true);
    const { error, data } = await getUserLogged();
    setLoading(false);
    if (!error) {
      setAuthedUser(data);
      navigate('/');
    }
  }

  function onLogout() {
    putAccessToken('');
    setAuthedUser(null);
    navigate('/login');
  }

  if (initializing) {
    return (
      <ThemeProvider value={themeContextValue}>
        <LocaleProvider value={localeContextValue}>
          <div className="full-loader">
            <div className="spinner"></div>
            <p>Memuat aplikasi...</p>
          </div>
        </LocaleProvider>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider value={themeContextValue}>
      <LocaleProvider value={localeContextValue}>
        <div className="app-container">
          {loading && <LoadingIndicator />}
          <Navigation authedUser={authedUser} logout={onLogout} />
          <main>
            {authedUser === null ? (
              <Routes>
                <Route
                  path="/login"
                  element={<LoginPage loginSuccess={onLoginSuccess} setLoading={setLoading} />}
                />
                <Route
                  path="/register"
                  element={<RegisterPage setLoading={setLoading} />}
                />
                <Route path="*" element={<Navigate to="/login" replace />} />
              </Routes>
            ) : (
              <Routes>
                <Route path="/" element={<HomePage setLoading={setLoading} />} />
                <Route path="/archives" element={<ArchivedPage setLoading={setLoading} />} />
                <Route path="/notes/new" element={<AddPage setLoading={setLoading} />} />
                <Route path="/notes/:id" element={<DetailPage setLoading={setLoading} />} />
                <Route path="/login" element={<Navigate to="/" replace />} />
                <Route path="/register" element={<Navigate to="/" replace />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            )}
          </main>
        </div>
      </LocaleProvider>
    </ThemeProvider>
  );
}

export default App;
