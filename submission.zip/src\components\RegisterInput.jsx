import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import useInput from '../hooks/useInput';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function RegisterInput({ register }) {
  const [name, onNameChangeHandler] = useInput('');
  const [email, onEmailChangeHandler] = useInput('');
  const [password, onPasswordChangeHandler] = useInput('');
  const [confirmPassword, onConfirmPasswordChangeHandler] = useInput('');
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  const onSubmitHandler = (event) => {
    event.preventDefault();
    if (password !== confirmPassword) {
      alert(t.passwordsDoNotMatch);
      return;
    }
    register({ name, email, password });
  };

  return (
    <form onSubmit={onSubmitHandler} className="input-register">
      <div>
        <label htmlFor="name">{t.nameLabel}</label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={onNameChangeHandler}
          required
        />
      </div>
      <div>
        <label htmlFor="email">{t.emailLabel}</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={onEmailChangeHandler}
          required
          autoComplete="email"
        />
      </div>
      <div>
        <label htmlFor="password">{t.passwordLabel}</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={onPasswordChangeHandler}
          required
          autoComplete="new-password"
        />
      </div>
      <div>
        <label htmlFor="confirmPassword">{t.confirmPasswordLabel}</label>
        <input
          type="password"
          id="confirmPassword"
          value={confirmPassword}
          onChange={onConfirmPasswordChangeHandler}
          required
          autoComplete="new-password"
        />
      </div>
      <button type="submit">{t.registerButton}</button>
    </form>
  );
}

RegisterInput.propTypes = {
  register: PropTypes.func.isRequired,
};

export default RegisterInput;
