import React, { useState, useEffect, useContext } from 'react';
import PropTypes from 'prop-types';
import { useSearchParams } from 'react-router-dom';
import SearchBar from '../components/SearchBar';
import NoteList from '../components/NoteList';
import { getArchivedNotes } from '../utils/network-data';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function ArchivedPage({ setLoading }) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [notes, setNotes] = useState([]);
  const [keyword, setKeyword] = useState(() => searchParams.get('title') || '');
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  useEffect(() => {
    async function fetchArchivedNotes() {
      if (setLoading) setLoading(true);
      const { error, data } = await getArchivedNotes();
      if (!error) {
        setNotes(data);
      }
      if (setLoading) setLoading(false);
    }

    fetchArchivedNotes();
  }, [setLoading]);

  function onKeywordChangeHandler(newKeyword) {
    setKeyword(newKeyword);
    setSearchParams(newKeyword ? { title: newKeyword } : {});
  }

  const filteredNotes = notes.filter((note) =>
    note.title.toLowerCase().includes(keyword.toLowerCase())
  );

  return (
    <section className="archived-page">
      <h2>{t.archivedNotes}</h2>
      <SearchBar keyword={keyword} keywordChange={onKeywordChangeHandler} />
      <NoteList notes={filteredNotes} emptyMessage={t.noArchivedNotes} />
    </section>
  );
}

ArchivedPage.propTypes = {
  setLoading: PropTypes.func,
};

export default ArchivedPage;
