import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import NoteItem from './NoteItem';
import LocaleContext from '../contexts/LocaleContext';
import { translations } from '../utils/content';

function NoteList({ notes, emptyMessage }) {
  const { locale } = useContext(LocaleContext);
  const t = translations[locale];

  if (!notes.length) {
    return (
      <section className="notes-list-empty">
        <p>{emptyMessage || t.noActiveNotes}</p>
      </section>
    );
  }

  return (
    <section className="notes-list">
      {notes.map((note) => (
        <NoteItem key={note.id} {...note} />
      ))}
    </section>
  );
}

NoteList.propTypes = {
  notes: PropTypes.arrayOf(PropTypes.object).isRequired,
  emptyMessage: PropTypes.string,
};

export default NoteList;
